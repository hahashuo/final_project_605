# code is only run when the english language package can be loaded
if(require("koRpus.lang.en", quietly = TRUE)){
